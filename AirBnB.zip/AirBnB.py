#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px #more common and simple use
import plotly.graph_objects as go #work moslty on graph objects (more heavy and dynamic) easier to control
from sklearn.model_selection import train_test_split


# In[2]:


air_BNB_Train = pd.read_csv("train_airBNB.csv")


# In[3]:


air_BNB_Train.head()


# In[4]:


#first drop of unnecessary features for prediction 
with open('featuers_removed_unnecessary.txt','w') as f:
  f.write('The features removed are : scrape_id,listing_url,name, review_scores_rating,last_scraped,picture_url,host_url,calendar_last_scraped,license,first_review,last_review ')
air_BNB_Train.drop(['scrape_id','host_thumbnail_url','host_picture_url','listing_url','host_has_profile_pic','host_since','last_scraped','picture_url','name','host_url','calendar_last_scraped','license','first_review','host_location','last_review','host_name','host_id','review_scores_rating'],axis = 1,inplace = True)


# In[5]:


air_BNB_Train.isnull().sum()
#Drop all the featuers that have more than 4000 Null values
air_BNB_Train.dropna(axis=1, thresh=8000, inplace=True)


# In[6]:


air_BNB_Train.isnull().sum()


# In[7]:


#Check how many unique values we have in each column
air_BNB_Train.nunique()


# In[8]:


temp = air_BNB_Train['price'].str.replace('$', '')
p = temp.str.replace(',', '')
p = p.astype(float)
type(p[0])
air_BNB_Train['price'] = p
price = air_BNB_Train['price']


# In[9]:


#Delete Columns that require NLP or further Geopy process
air_BNB_Train.drop(['amenities','description','latitude','longitude','bathrooms_text','accommodates','host_verifications'],axis = 1,inplace = True)


# In[10]:


# Replace f with 0 and t with 1 
air_BNB_Train.host_is_superhost.replace({'t':1, 'f':0}, inplace=True)
air_BNB_Train.has_availability.replace({'t':1, 'f':0}, inplace=True)
air_BNB_Train.host_identity_verified.replace({'t':1, 'f':0}, inplace=True)


# In[11]:


air_BNB_Train = pd.get_dummies(air_BNB_Train, columns=['neighbourhood_cleansed'])
air_BNB_Train = pd.get_dummies(air_BNB_Train, columns=['property_type'])
air_BNB_Train = pd.get_dummies(air_BNB_Train, columns=['room_type'])


# In[12]:


corr_df = air_BNB_Train.corr()
corr_df


# In[13]:


fig = go.Figure()
fig.add_traces(go.Heatmap(
    z=corr_df, 
    x=corr_df.columns, 
    y=corr_df.columns,
    zmax=1, 
    zmin=-1
))
fig.update_layout({
    'title':"Features Correlation Heatmap"
})


# In[14]:


for i in range(len(corr_df.columns)-1):
  print(corr_df.columns[i], 'is correlated to: ')
  for j in range(len(corr_df.columns)-1):
    if abs(corr_df.iloc[i,j])>=0.85 and i is not j:
      print(corr_df.columns[j], end=', ')
  print('\n----------------------')


# In[15]:


#Drop according to correlation.
air_BNB_Train.drop(['minimum_nights','minimum_minimum_nights', 'maximum_minimum_nights','maximum_maximum_nights','host_listings_count','availability_30', 'availability_60','minimum_nights', 'minimum_minimum_nights', 'minimum_nights_avg_ntm'],axis = 1,inplace = True)


# In[16]:


air_BNB_Train.host_is_superhost.fillna(value = air_BNB_Train.host_is_superhost.value_counts().index[0], inplace = True)
air_BNB_Train.host_total_listings_count.fillna(value = air_BNB_Train.host_total_listings_count .value_counts().index[0], inplace = True)
air_BNB_Train.host_identity_verified.fillna(value = air_BNB_Train.host_identity_verified.value_counts().index[0], inplace = True)
air_BNB_Train.bedrooms.fillna(value = air_BNB_Train.bedrooms.value_counts().index[0], inplace = True)
air_BNB_Train.beds.fillna(value = air_BNB_Train.beds.value_counts().index[0], inplace = True)
air_BNB_Train.maximum_nights_avg_ntm.fillna(value = air_BNB_Train.maximum_nights_avg_ntm.value_counts().index[0], inplace = True)
air_BNB_Train.minimum_maximum_nights .fillna(value = air_BNB_Train.minimum_maximum_nights .value_counts().index[0], inplace = True)


# In[17]:


X = air_BNB_Train.drop('price', axis= 1)
y = price


# In[18]:


X.isnull().sum().head(30)


# In[19]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1234)
train_df = pd.merge(left=X_train, right=y_train, left_index=True, right_index=True)
test_df = pd.merge(left=X_test, right=y_test, left_index=True, right_index=True)
train_df.head(10)


# In[20]:


from sklearn.linear_model import LinearRegression
lm = LinearRegression()  # define our model using least square method
lm.fit(X_train,y_train)

#use lm.predict(X_train_scaled) for all the living area data from the train set
fitted_scaled_price = lm.predict(X_train) # returns ndarray

#inverse the scaler transformation
fitted_price = y_train


# In[21]:


train_df['residuals'] = fitted_scaled_price -fitted_price


# In[22]:


fig= go.Figure()
fig.add_trace(
    go.Scatter(
        x=fitted_scaled_price,
        y=train_df.residuals,
        mode='markers',
        name='train residuals',
        marker_color='blue',
        marker_size=2.5,
        marker_line_width=0,

    )
)
fig.add_trace(
  go.Scatter(
      x=fitted_scaled_price,
      y=train_df.residuals*0,
      mode='lines',
      name='zero line',
      marker_color='black',
      marker_size=1.5,
      marker_line_width=0,

  )
)
fig.update_layout(
    title="Residuals of Predicted prices",
    xaxis_title="Predicted price",
    yaxis_title="Residuals",
    font=dict(
        size=14,
        color="RebeccaPurple"
    )
)
fig.show()


# In[23]:


from sklearn import metrics

print("------ TRAIN DATA ------")
print("MSE:",metrics.mean_squared_error(fitted_price, fitted_scaled_price))
print("RMSE:",np.sqrt(metrics.mean_squared_error(fitted_price, fitted_scaled_price)))
print("MAE:",metrics.mean_absolute_error(fitted_price, fitted_scaled_price))


# In[24]:


air_BNB_test= pd.read_csv("test_airBNB.csv")


# In[25]:


air_BNB_test.drop(['scrape_id','host_thumbnail_url','host_picture_url','listing_url','host_has_profile_pic','host_since','last_scraped','picture_url','name','host_url','calendar_last_scraped','license','first_review','host_location','last_review','host_name','host_id'],axis = 1,inplace = True)
air_BNB_test.drop(['amenities','description','latitude','longitude','bathrooms_text','accommodates','host_verifications'],axis = 1,inplace = True)
air_BNB_test.drop(['minimum_nights','minimum_minimum_nights', 'maximum_minimum_nights','maximum_maximum_nights','host_listings_count','availability_30', 'availability_60','minimum_nights', 'minimum_minimum_nights', 'minimum_nights_avg_ntm'],axis = 1,inplace = True)
air_BNB_test.drop(['neighborhood_overview','host_about', 'host_response_time','host_acceptance_rate','host_neighbourhood','neighbourhood', 'neighbourhood_group_cleansed', 'calendar_updated'],axis = 1,inplace = True)


# In[26]:


air_BNB_test.dropna(axis=1, thresh=3200, inplace=True)


# In[27]:


air_BNB_test.isnull().sum()


# In[28]:


air_BNB_test.host_is_superhost.fillna(value = air_BNB_test.host_is_superhost.value_counts().index[0], inplace = True)
air_BNB_test.host_total_listings_count.fillna(value = air_BNB_test.host_total_listings_count .value_counts().index[0], inplace = True)
air_BNB_test.host_identity_verified.fillna(value = air_BNB_test.host_identity_verified.value_counts().index[0], inplace = True)
air_BNB_test.bedrooms.fillna(value = air_BNB_test.bedrooms.value_counts().index[0], inplace = True)
air_BNB_test.beds.fillna(value = air_BNB_test.beds.value_counts().index[0], inplace = True)
air_BNB_test.maximum_nights_avg_ntm.fillna(value = air_BNB_test.maximum_nights_avg_ntm.value_counts().index[0], inplace = True)
air_BNB_test.minimum_maximum_nights .fillna(value = air_BNB_test.minimum_maximum_nights .value_counts().index[0], inplace = True)


# In[29]:


# Replace f with 0 and t with 1 
air_BNB_test.host_is_superhost.replace({'t':1, 'f':0}, inplace=True)
air_BNB_test.has_availability.replace({'t':1, 'f':0}, inplace=True)
air_BNB_test.host_identity_verified.replace({'t':1, 'f':0}, inplace=True)


# In[30]:


air_BNB_test = pd.get_dummies(air_BNB_test, columns=['neighbourhood_cleansed'])
air_BNB_test = pd.get_dummies(air_BNB_test, columns=['property_type'])
air_BNB_test = pd.get_dummies(air_BNB_test, columns=['room_type'])


# In[31]:


test_columns = air_BNB_test.columns
train_columns = air_BNB_Train.columns
m = []
for i in train_columns:
  if(i not in test_columns):
    m.append(i)
for i in m:
  if(i != 'price'):
    air_BNB_test[i] = 0


# In[32]:


test_columns = air_BNB_test.columns
train_columns = air_BNB_Train.columns
m = []
for i in test_columns:
  if(i not in train_columns):
    m.append(i)
for i in m:
  air_BNB_test.drop([i], axis =1, inplace = True)


# In[33]:


fitted_scaled_price_test = lm.predict(air_BNB_test)


# In[34]:


air_BNB_Train.columns


# In[35]:


from dash import Dash, html, dcc, Input, Output,dash_table
import dash_bootstrap_components as dbc
import plotly.graph_objects as go
app = Dash()


# In[36]:


layout = go.Layout(
    margin=go.layout.Margin(
        l=40,  # left margin
        r=40,  # right margin
        b=10,  # bottom margin
        t=35  # top margin
    ))


# In[37]:


AirBnB_dropdown = dcc.Dropdown(options=air_BNB_Train['beds'].unique(),
                            value=3)


# In[38]:


@app.callback(
    Output(component_id='price-graph', component_property='figure'),
    Input(component_id=AirBnB_dropdown, component_property='value')
)
def update_graph(selected_beds):
    filtered_AirBnB = air_BNB_Train[air_BNB_Train['beds'] == selected_beds]
    line_fig = px.line(filtered_AirBnB,
                       x='host_is_superhost', y='price',
                       color='maximum_nights',
                       title=f'AirBnB Prices for appartment with {selected_beds} beds and the correlation to maximum_nights',
                       width=600, height=400)
    return line_fig


# In[39]:


def pie_graph():
    pieChart = dcc.Graph(
        figure=go.Figure(layout=layout).add_trace(go.Pie(
            labels=air_BNB_Train['bedrooms'],
            values=air_BNB_Train['host_total_listings_count'],
            marker=dict(colors=['#120303', '#300f0f', '#381b1b', '#4f2f2f', '#573f3f', '#695a5a', '#8a7d7d'],
                        line=dict(color='#ffffff', width=2)))).update_layout(title='Bedrooms Rate with accordence to host_total_listings_count ',
                                                                             plot_bgcolor='rgba(0,0,0,0)',
                                                                             showlegend=False),
        style={'width': 600,'height': 400, 'display': 'inline-block'})
    return pieChart


# In[40]:


app.layout = html.Div([
    html.Div([
        html.Div([
            html.H1(
                children ='AirBnB Prices Dashboard'),
                AirBnB_dropdown
        ], className="six columns"),
         html.Div([
              dcc.Graph(id='price-graph',style = {'display' : 'inline-block'}),
                pie_graph()
         ], className="six columns"),
        html.Div([
            html.H1('DF', style={'text-align': 'center'}),
            dash_table.DataTable(air_BNB_Train.to_dict('records'), [{"name": i, "id": i} for i in air_BNB_Train.columns],
                 style_table={'overflowX': 'auto','height': '200px'}),
          ] , className="six columns"),
    ], className="row"),
    
])

app.css.append_css({
    'external_url': 'https://codepen.io/chriddyp/pen/bWLwgP.css'
    })


# In[ ]:


if __name__ == '__main__':
    app.run_server(debug=False)


# In[ ]:




